import numpy as np
# para manejar input/output de archivos de audio
import soundfile as sf

# velocidad del sonido 
c = 343.0 # [m/s]

# Para interpolar entre sampleos del archivo del audio
def interpolacion(signal, times, fs):
    k_r = np.arange(0, len(signal), 1)        
    k = k_r - times * fs                      
    kf = np.floor(k).astype(int)              
    R = ( (1.0-k+kf) * signal[kf] + (k-kf) * signal[kf+1] ) * (kf >= 0) 
    return R

# Una clase para controlar la fuente de sonido
class AudioSource:
    def __init__(self, r_s, v_t, wav_name):
        self.r_s = r_s
        self.v_t = v_t
        self.w = self.v_t/self.r_s
        self.sampling_rate = 44100
        self.wav_file = sf.read(wav_name)
        self.wav_samplerate = self.wav_file[1]
        self.wav_data = self.wav_file[0]
        self.wav_duration = len(self.wav_data)/self.wav_samplerate
        self.T = np.linspace(0, self.wav_duration, len(self.wav_data))

# Una clase para manejar un observador
class Observer:
    def __init__(self, audio_source, obs_sample_rate):
        self.x = 0
        self.y = 0
        self.sample_rate = obs_sample_rate
        self.audio_stream = np.array([])
        self.audio_source = audio_source
        self.d_os = np.array([])

    # calcular la distancia entre el observador y el sonido
    def d_os_v_s(self, t):
        self.r_o = np.sqrt(self.x**2 + self.y**2)
        theta_s = self.audio_source.v_t/self.audio_source.r_s*t
        d_os = np.sqrt(self.r_o**2 + self.audio_source.r_s**2 - 2*self.r_o*self.audio_source.r_s*np.cos(theta_s))
        return d_os

    # Calcular el sonido resultante
    def interpolated_audio_stream(self, T):
        # Calculamos la distancia entre el observador y el sonido a lo largo del audio
        self.d_os = self.d_os_v_s(self.audio_source.T)
        self.audio_stream = np.array([])
        # Si T es mayor que el tiempo de duracion del audio, entonces se 
        # repite el audio
        for i in range(int(T // self.audio_source.wav_duration)):
            self.audio_stream = np.append(self.audio_stream, self.audio_source.wav_data)
        self.audio_stream = np.append(self.audio_stream, self.audio_stream[:int(T*self.sample_rate) % len(self.audio_stream)])
        # Interpolar el audio, con los sampleos corridos debido a la distancia del
        # observador al sonido
        d_os_i = interpolacion(self.audio_stream, self.d_os/c, self.sample_rate)
        self.audio_stream = d_os_i

    # Guardar el audio en un archivo
    def saveAudioStream(self, name):
        sf.write(name, self.audio_stream, self.audio_source.sampling_rate)