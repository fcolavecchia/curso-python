import numpy as np
import argparse
from itertools import count

import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backend_bases import MouseButton

import sound

parser = argparse.ArgumentParser(
      description='"Tiro vertical"')

parser.add_argument('-i', '--wav_in', action='store', dest='wav_name', default=None, type=str)
parser.add_argument('-rs', '--radio_s', action='store', dest='r_s', default=5., type=float)
# Agrego un argumento para velocidad de la fuente
parser.add_argument('-vt', '--velocidad_tangencial', action='store', dest='v_t', default=10., type=float)
# Posiciones x,y del observador
parser.add_argument('-x', action='store', dest='x', default=0., type=float)
parser.add_argument('-y', action='store', dest='y', default=0., type=float)
# Modo interactivo o no
parser.add_argument('--interactivo', action='store_true', dest='interactivo', default=False)
# Si se activa save-interactivo, cada vez que se actualiza la animación se guarda el nuevo 
# audio resultante. No tiene efecto si estamos en modo no interactivo
parser.add_argument('--save-interactivo', action='store_true', dest='save_interactivo', default=False)
args = parser.parse_args()

# Creamos una fuente de audio
S = sound.AudioSource(r_s=args.r_s, v_t=args.v_t, wav_name=args.wav_name)
# Creamos un observador
O = sound.Observer(audio_source=S, obs_sample_rate=44100)
O.x = args.x
O.y = args.y
# Calculamos el audio resultante
O.interpolated_audio_stream(T=S.wav_duration)

if not args.interactivo:
    O.saveAudioStream(args.wav_name[:-4]+'_doppler.wav')

else:
    plt.ioff()
    # Creamos los datos
    xmax = 2*np.pi

    fig = plt.figure()
    animAx = plt.subplot(1, 2, 1)
    animAx.set_title('Tren en movimiento circular')
    animAx.set_xticks([])
    animAx.set_yticks([])
    animAx.set_xlim(-S.r_s*1.1, S.r_s*1.1)
    animAx.set_ylim(-S.r_s*1.1, S.r_s*1.1)
    rail_circles = [plt.Circle((0, 0), S.r_s*1.06, color='black', fill=False),
                    plt.Circle((0, 0), S.r_s*0.94, color='black', fill=False)]
    animAx.add_patch(rail_circles[0])
    animAx.add_patch(rail_circles[1])
    posAx = plt.subplot(2, 2, 2)
    posAx.set_xlim(0, S.wav_duration)
    posAx.set_ylim(-0.1, max(O.d_os)*1.1)
    posAx.set_xlabel('Tiempo [s]')
    posAx.set_ylabel('Distancia [m]')
    posAx.set_title('Distancia al observador')
    wavAx = plt.subplot(2, 2, 4)
    wavAx.set_xlabel('Tiempo [s]')
    wavAx.set_ylabel('Intensidad [rel]')
    wav_plot, = wavAx.plot(S.T, O.audio_stream)

    src_circle = plt.Circle((S.r_s, 0), radius=0.05*S.r_s, color='r', fill=True)
    obs_circle = plt.Circle((O.x, O.y), radius=0.05*S.r_s, color='b', fill=True)
    dos_line, = posAx.plot([], [])

    # Esta función se activa cuando hay un click del mouse
    def on_click(event):
        # Chequeamos que el click sea click izquierdo
        if event.button is MouseButton.LEFT:
            # Chequeamos que el click sea sobre el Axes de la animación
            if animAx == event.inaxes:
                O.x = event.xdata
                O.y = event.ydata
                obs_circle.center = (O.x, O.y)
                O.interpolated_audio_stream(T=S.wav_duration)
                if args.save_interactivo:
                    O.saveAudioStream(args.wav_name[:-4]+'_doppler.wav')
                #animation_animAx.frame_seq = count(0)

                dos_line.set_data([], [])
                posAx.set_xlim(0, S.wav_duration)
                posAx.set_ylim(-0.1, max(O.d_os)*1.1)
                #animation_posAx.frame_seq = count(0)
                wav_plot.set_data(S.T, O.audio_stream)
                fig.canvas.draw()

    def init_animAx():
        animAx.add_patch(src_circle)
        animAx.add_patch(obs_circle)
        return src_circle, obs_circle,

    def update_animation(i):
        n = int(len(O.audio_stream)*i/100/S.wav_duration)
        t = n/S.sampling_rate
        #t = 0
        src_circle.center = (S.r_s*np.cos(S.w*t*2*np.pi), S.r_s*np.sin(S.w*t*2*np.pi))
        n = n % len(O.audio_stream)
        dos_line.set_data([S.T[:n:100], O.d_os[:n:100]])
        #print('Source position: ({}, {})'.format(src_circle.center[0], src_circle.center[1]))
        return src_circle, obs_circle, dos_line,

    plt.connect('button_press_event', on_click)
    animation = animation.FuncAnimation(fig, update_animation, init_func=init_animAx, interval=1, blit=True)

    plt.show()